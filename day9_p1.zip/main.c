/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int p,n,count;
float r,si;
for(count=1; count<=3; count=count+1)
{
    printf("Enter values of p,n,and r");
    scanf("%d %d %f",&p,&n,&r);
    si=p*n*r/100;
    printf("Simplr interest= Rs.%f\n",si);
}
return 0;
    
}